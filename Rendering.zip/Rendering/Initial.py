import taichi as ti
import taichi.math as tm

# taichi scope
ti.init(arch=ti.vulkan)
