import taichi as ti
import taichi.math as tm

import Ray
import Object
import Math
import SDF
import Camera as Cm

from Config import SAMPLE_PER_PIXELS, QUALITY_PER_SAMPLE, SCREEN_PIXEL_SIZE, ASPECT_RATIO
from Config import VISIBILITY, PIXEL_RADIUS, APERTURE, FOV, FOCUS

from Fields import image_pixels, image_buffer, ray_buffer


@ti.dataclass
class raycast:
    ray: Ray.Ray
    obj: Object.Object
    hit: bool


@ti.func
def background_shading(ray) -> tm.vec3:
    return tm.vec3(1, 1, 1)


@ti.func
def ray_cast(ray) -> raycast:
    t, w, s, distance = 0.0, 1.88, 0.0, 1e9
    obj, hit = Object.Object(), False
    for i in range(Ray.MAX_RAYMARCH):
        ld = distance
        obj, distance = SDF.nearest_object(ray.origin)

        if w > 1.0 and ld + distance < s:
            s -= w * s
            w = 1.0
            t += s
            ray.origin += ray.direction * s
            continue
        s = w * distance
        t += s
        ray.origin += ray.direction * s

        hit = distance < t * PIXEL_RADIUS
        if hit or t >= Ray.TMAX:
            break

    ray.depth += 1
    return raycast(ray, obj, hit)


@ti.func
def ray_trace(ray) -> Ray.Ray:
    rayc = ray_cast(ray)
    ray, object, hit = rayc.ray, rayc.obj, rayc.hit

    if hit:
        ray = Ray.BSDF(ray, object)

        intensity = Math.brightnness(ray.color)
        ray.color *= object.mtl.emission
        visible = Math.brightnness(ray.color)

        stop = intensity < visible or visible < VISIBILITY.x or visible > VISIBILITY.y
        ray.depth *= -1 if stop else 1
    else:
        ray.depth *= -1
        ray.color *= background_shading(ray)

    return ray


@ti.func
def generate_ray(position: tm.vec3, lookat: tm.vec3, up: tm.vec3, uv: tm.vec2) -> Ray:
    camera = Cm.Camera()
    camera.position = position
    camera.lookat = lookat
    camera.up = up
    camera.aspect = ASPECT_RATIO
    camera.fov = FOV
    camera.aperture = APERTURE
    camera.focus = FOCUS
    return camera.get_ray(uv, tm.vec3(1))


@ti.func
def fire(p: tm.vec3, l: tm.vec3, u: tm.vec3, ray: Ray.Ray, i: int, j: int):
    if ray.depth < 1 or ray.depth > Ray.MAX_PATHTRACE:
        image_buffer[i, j] += tm.vec4(ray.color, 1.0)

        coord = tm.vec2(i, j) + tm.vec2(ti.random(), ti.random())
        uv = coord * SCREEN_PIXEL_SIZE
        ray = generate_ray(p, l, u, uv)

    return ray_trace(ray)


@ti.func
def russian_roulette(p: tm.vec3, l: tm.vec3, u: tm.vec3, ray: Ray.Ray, i: int, j: int) -> Ray:
    pdf = 1.0 if ray.depth <= 1 else QUALITY_PER_SAMPLE
    pdf -= ray.depth * ti.static(1.0 / Ray.MAX_PATHTRACE)

    if ti.random() > pdf:
        ray.color = tm.vec3(0)
        ray.depth *= -1
    else:
        ray.color *= 1.0 / pdf
        ray = fire(p, l, u, ray, i, j)
    return ray


@ti.func
def sample(p: tm.vec3, l: tm.vec3, u: tm.vec3, i: int, j: int):
    ray = ray_buffer[i, j]

    for _ in range(SAMPLE_PER_PIXELS):
        ray = russian_roulette(p, l, u, ray, i, j)

    ray_buffer[i, j] = ray


@ti.kernel
def path_trace(p: tm.vec3, l: tm.vec3, u: tm.vec3):
    for i, j in image_pixels:
        sample(p, l, u, i, j)


@ti.kernel
def refresh():
    for i, j in image_buffer:
        image_pixels[i, j] = tm.vec3(ti.random())
        ray_buffer[i, j].depth = -1


@ti.kernel
def post_process():
    for i, j in image_pixels:
        last_color = image_pixels[i, j]
        buffer = image_buffer[i, j]

        color = buffer.rgb / buffer.a

        image_pixels[i, j] = tm.clamp(color, 0, 1)