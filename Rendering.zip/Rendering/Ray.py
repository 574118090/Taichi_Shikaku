import taichi as ti
import taichi.math as tm

import Math
import Object
import SDF

# ray-cast scope
TMIN = 0.001
TMAX = 1000.0
PRECISION = 1e-3  # @Shadow Acne

MAX_RAYMARCH = 512
MAX_PATHTRACE = 512

IOR = 0.9876


@ti.dataclass
class Ray:
    origin: tm.vec3
    direction: tm.vec3
    color: tm.vec3
    depth: int


@ti.dataclass
class RayHit:
    position: tm.vec3
    distance: float
    hit: ti.i32
    obj: Object.Object


@ti.func
def TBN(N: tm.vec3) -> tm.mat3:
    T = tm.vec3(0.0)
    B = tm.vec3(0.0)

    if (N.z < -1 + 1e-6):
        T = tm.vec3(0.0, -1.0, 0.0)
        B = tm.vec3(-1.0, 0.0, 0.0)
    else:
        a = 1.0 / (1.0 + N.z)
        b = -N.x * N.y * a

        T = tm.vec3(1.0 - N.x * N.x * a, b, -N.x)
        B = tm.vec3(b, 1.0 - N.y * N.y * a, -N.y)

    return tm.mat3(T, B, N)


@ti.func
def hemispheric_sampling(n: tm.vec3) -> tm.vec3:
    vector = Math.random_in_unit_sphere()
    return tm.normalize(n + vector)


@ti.func
def hemispheric_sampling_roughness(n: tm.vec3, roughness: float) -> tm.vec3:
    ra = ti.random() * 2 * tm.pi
    rb = ti.random()

    shiny = tm.pow(roughness, 5)

    rz = tm.sqrt((1.0 - rb) / (1.0 + (shiny - 1.0) * rb))
    v = tm.vec2(tm.cos(ra), tm.sin(ra))
    rxy = tm.sqrt(abs(1 - rz * rz)) * v

    return TBN(n) @ tm.vec3(rxy, rz)


@ti.func
def BSDF(ray: Ray, object: Object.Object) -> Ray:
    albedo = object.mtl.albedo
    roughness = object.mtl.roughness
    metallic = object.mtl.metallic
    transmission = object.mtl.transmission
    ior = object.mtl.ior

    normal = SDF.get_normal(object, ray.origin)
    outer = tm.dot(ray.direction, normal) < 0.0
    normal *= 1.0 if outer else -1.0

    alpha = roughness * roughness
    hemispheric_sample = hemispheric_sampling(normal)
    roughness_sample = tm.normalize(tm.mix(normal, hemispheric_sample, alpha))

    N = roughness_sample
    I = ray.direction
    NoI = tm.dot(N, I)

    eta = IOR / ior if outer else ior / IOR
    k = 1.0 - eta * eta * (1.0 - NoI * NoI)
    f0 = 2.0 * (eta - 1.0) / (eta + 1.0)
    f = Object.fresnel_schlick(NoI, f0 * f0)

    if ti.random() < f + metallic or k < 0.0:
        ray.direction = I - 2.0 * NoI * N
        outer = tm.dot(ray.direction, normal) < 0.0
        ray.direction *= (-1.0 if outer else 1.0)
    elif ti.random() < transmission:
        ray.direction = eta * I - (tm.sqrt(k) + eta * NoI) * N
    else:
        ray.direction = hemispheric_sample

    ray.color *= albedo

    outer = tm.dot(ray.direction, normal) < 0.0
    ray.origin += normal * TMIN * (-1.0 if outer else 1.0)

    return ray
