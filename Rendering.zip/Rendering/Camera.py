import taichi as ti
import taichi.math as tm

import Ray

from Fields import image_buffer, image_pixels, temp_image_pixels, temp_image_buffer
from Config import RESOLUTION_RATIO


@ti.func
def random_in_unit_disk():
    x = ti.random()
    a = ti.random() * 2 * tm.pi
    return tm.sqrt(x) * tm.vec2(tm.sin(a), tm.cos(a))


@ti.dataclass
class Camera:
    position: tm.vec3
    lookat: tm.vec3
    up: tm.vec3
    fov: float  # 纵向视野
    aspect: float  # 长宽比
    aperture: float  # 光圈大小
    focus: float  # 焦距

    @ti.func
    def get_ray(self, uv: tm.vec2, color: tm.vec3) -> Ray.Ray:
        theta = tm.radians(self.fov)
        half_height = tm.tan(theta * 0.5)
        half_width = self.aspect * half_height

        z = tm.normalize(self.position - self.lookat)
        x = tm.normalize(tm.cross(self.up, z))
        y = tm.cross(z, x)

        start_pos = self.position - half_width * self.focus * x - half_height * self.focus * y - self.focus * z

        horizontal = 2.0 * half_width * self.focus * x
        vertical = 2.0 * half_height * self.focus * y

        lens_radius = self.aperture * 0.5  # 透镜半径 = 光圈大小的一半（归一化）
        rud = lens_radius * random_in_unit_disk()  # 随机采样点 = 光圈范围 * 随机采样
        offset = x * rud.x + y * rud.y  # 计算光圈中随机采样点的偏移量

        # 计算光线
        ro = self.position + offset
        rp = start_pos + uv.x * horizontal + uv.y * vertical
        rd = tm.normalize(rp - ro)

        return Ray.Ray(ro, rd, color)


@ti.kernel
def update_transform(x: int, y: int):
    X = x * 1
    Y = y * 1
    for i, j in image_buffer:
        if 0 <= i + X < RESOLUTION_RATIO[0] and 0 <= j + Y < RESOLUTION_RATIO[1]:
            image_pixels[i, j] = temp_image_pixels[i + X, j + Y]
            image_buffer[i, j] = temp_image_buffer[i + X, j + Y]
        else:
            image_pixels[i, j] = tm.vec3(0)
            image_buffer[i, j] = tm.vec4(0)
