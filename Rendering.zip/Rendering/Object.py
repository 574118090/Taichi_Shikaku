import taichi as ti
import taichi.math as tm

import Ray

NONE = 0
SPHERE = 1
CUBE = 2


@ti.dataclass
class Material:
    albedo: tm.vec3
    roughness: float  # 粗糙度
    metallic: float  # 金属度
    transmission: float  # 透明度
    ior: float  # 折射率
    emission: tm.vec3  # 自发光
    normal: tm.vec3

    def __init__(self, albedo, roughness, metallic, transmission, ior, emission, normal):
        self.albedo = albedo
        self.roughness = roughness
        self.metallic = metallic
        self.transmission = transmission
        self.ior = ior
        self.emission = emission
        self.normal = normal


@ti.dataclass
class Transform:
    position: tm.vec3
    scale: tm.vec3
    rotation: tm.vec3

    def __init__(self, pos: tm.vec3, scl: tm.vec3, rot: tm.vec3):
        self.position = pos
        self.scale = scl
        self.rotation = rot


@ti.dataclass
class Object:
    type: ti.u32
    mtl: Material
    trans: Transform
    sd: float

    def __init__(self, type: ti.u32, trans: Transform, mtl: Material):
        self.type = type
        self.trans = trans
        self.mtl = mtl
        self.sd = 1e9


@ti.func
def rotate(a: tm.vec3) -> tm.mat3:
    s = tm.sin(a)
    c = tm.cos(a)
    return tm.mat3(tm.vec3(c.z, s.z, 0),
                   tm.vec3(-s.z, c.z, 0),
                   tm.vec3(0, 0, 1)) @ \
           tm.mat3(tm.vec3(c.y, 0, -s.y),
                   tm.vec3(0, 1, 0),
                   tm.vec3(s.y, 0, c.y)) @ \
           tm.mat3(tm.vec3(1, 0, 0),
                   tm.vec3(0, c.x, s.x),
                   tm.vec3(0, -s.x, c.x))


@ti.func
def fresnel_schlick(NoI: float, f0: float) -> float:
    return tm.mix(tm.pow(abs(1.0 + NoI), 5.0), 1.0, f0)


@ti.func
def fresnel_schlick_roughness(cosine: float, f0: float, roughness: float) -> float:
    return f0 + (tm.max(1 - roughness, f0) - f0) * pow(abs(1 - cosine), 5)
