import taichi.math as tm

from Object import Object, Material, Transform
from Object import CUBE, SPHERE

object_num = 7

# Material:
# albedo: tm.vec3
# roughness: float  # 粗糙度
# metallic: float  # 金属度
# transmission: float  # 透明度
# ior: float  # 折射率
# emission: tm.vec4  # 自发光
# normal: tm.vec3

white_plastic = Material(tm.vec3(0.8, 0.8, 0.8) * 0.9, 0.8, 0.9, 0, 0.8, tm.vec3(1), tm.vec3(0, 0, 1))
red_plastic = Material(tm.vec3(1, 0.0, 0.0) * 0.9, 1, 1, 0, 1, tm.vec3(1), tm.vec3(0, 0, 1))
green_plastic = Material(tm.vec3(0, 1, 0.0) * 0.9, 1, 1, 0, 1, tm.vec3(1), tm.vec3(0, 0, 1))
light = Material(tm.vec3(1, 0.65, 0.34) * 0.9, 1, 1, 0, 1, tm.vec3(1, 0.65, 0.34) * 5, tm.vec3(0, 0, 1))
glass = Material(tm.vec3(1, 1, 1) * 0.9, 0, 1, -0.1, 2.95, tm.vec3(1), tm.vec3(0, 0, 1))
mirror = Material(tm.vec3(1, 1, 1) * 0.9, 0.01, 1, 0, 1, tm.vec3(1), tm.vec3(0, 0, 1))


# objects[i] = Object( type类型
# transform(position, scale, rotation)物理
# material材质
# )

def init():
    objects = Object.field(shape=object_num)

    objects[0] = Object(type=CUBE,
                        trans=Transform(tm.vec3(0, 1, 0), tm.vec3(1, 0.01, 1), tm.vec3(0, 0, 0)),
                        mtl=white_plastic)
    objects[1] = Object(type=CUBE,
                        trans=Transform(tm.vec3(0, -1, 0), tm.vec3(1, 0.01, 1), tm.vec3(0, 0, 0)),
                        mtl=white_plastic)
    objects[2] = Object(type=CUBE,
                        trans=Transform(tm.vec3(0, 0, -1), tm.vec3(1, 1, 0.01), tm.vec3(0, 0, 0)),
                        mtl=white_plastic)
    objects[3] = Object(type=CUBE,
                        trans=Transform(tm.vec3(-1, 0, 0), tm.vec3(0.01, 1, 1), tm.vec3(0, 0, 0)),
                        mtl=green_plastic)
    objects[4] = Object(type=CUBE,
                        trans=Transform(tm.vec3(1, 0, 0), tm.vec3(0.01, 1, 1), tm.vec3(0, 0, 0)),
                        mtl=red_plastic)
    objects[5] = Object(type=SPHERE,
                        trans=Transform(tm.vec3(-0.4, -0.7, 0.3), tm.vec3(0.3, 0.6, 0.2), tm.vec3(0, 0, 0)),
                        mtl=mirror)
    objects[6] = Object(type=CUBE,
                        trans=Transform(tm.vec3(0.4, -0.7, 0.3), tm.vec3(0.3, 0.3, 0.3), tm.vec3(0, 45, 0)),
                        mtl=mirror)
    return objects
