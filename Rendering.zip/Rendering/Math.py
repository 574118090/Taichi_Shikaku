import taichi as ti
import taichi.math as tm


@ti.func
def brightnness(rgb: tm.vec3) -> float:
    return tm.dot(rgb, tm.vec3(0.299, 0.587, 0.114))


@ti.func
def random_in_unit_sphere() -> tm.vec3:
    vec = tm.vec2(ti.random(),ti.random())
    z = 2.0 * vec.x - 1.0
    a = vec.y * 2.0 * tm.pi

    xy = tm.sqrt(1.0 - z * z) * tm.vec2(tm.sin(a), tm.cos(a))
    return tm.vec3(xy, z)
