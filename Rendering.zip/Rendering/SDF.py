import taichi as ti
import taichi.math as tm

import Object
import Scene

objects = Scene.init()
objects_num = Scene.object_num


@ti.func
def sdf_sphere(p: tm.vec3, r: float) -> float:
    return tm.length(p) - r


@ti.func
def sdf_cube(p: tm.vec3, b: tm.vec3) -> float:
    q = abs(p) - b
    return tm.length(tm.max(q, 0)) + tm.min(tm.max(q.x, q.y, q.z), 0)


@ti.func
def signed_distance(obj: Object.Object, pos: tm.vec3) -> float:
    position = obj.trans.position
    scale = obj.trans.scale

    p = pos - position
    p = Object.rotate(obj.trans.rotation) @ p

    if obj.type == Object.SPHERE:
        obj.sd = sdf_sphere(p, scale.x)
    elif obj.type == Object.CUBE:
        obj.sd = sdf_cube(p, scale)
    else:
        obj.sd = sdf_sphere(p, scale.x)
    return obj.sd


@ti.func
def nearest_object(p: tm.vec3):
    obj = Object.Object(sd=1e9)

    for i in range(objects_num):
        oi = objects[i]
        oi.sd = signed_distance(oi, p)
        if abs(oi.sd) < abs(obj.sd):
            obj = oi

    return obj, obj.sd


@ti.func
def get_normal(obj, p: tm.vec3):
    e = tm.vec2(1, -1) * 0.5773 * 0.0005
    return tm.normalize(e.xyy * signed_distance(obj, p + e.xyy) + \
                        e.yyx * signed_distance(obj, p + e.yyx) + \
                        e.yxy * signed_distance(obj, p + e.yxy) + \
                        e.xxx * signed_distance(obj, p + e.xxx))
