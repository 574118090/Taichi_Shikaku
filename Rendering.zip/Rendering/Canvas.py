import taichi as ti
import time

import Initial
import PathTracing
import Scene

from Config import RESOLUTION_RATIO, MOVING_SPEED
from Fields import image_pixels, image_buffer, temp_image_pixels, temp_image_buffer
from Camera import update_transform

refresh_frame = True

taichi_camera = ti.ui.Camera()


def render():
    if refresh_frame:
        PathTracing.refresh()
    else:
        PathTracing.path_trace(taichi_camera.curr_position, taichi_camera.curr_lookat, taichi_camera.curr_up)
    PathTracing.post_process()


window = ti.ui.Window("Shikaku Renderer", RESOLUTION_RATIO)
canvas = window.get_canvas()

Scene.init()

start_time = time.time()

refresh = False

taichi_camera = ti.ui.Camera()
taichi_camera.position(0, 0, 5)
taichi_camera.lookat(0, 0, 1)
taichi_camera.up(0, 1, 0)

while window.running:
    taichi_camera.track_user_inputs(window, movement_speed=MOVING_SPEED, hold_key=ti.ui.LMB)
    dt = time.time() - start_time

    # refresh camera
    refresh_frame = False
    # moving
    x = int(window.is_pressed('d')) - int(window.is_pressed('a'))
    y = int(window.is_pressed('w')) - int(window.is_pressed('s'))

    if not x == 0 and y == 0:
        print("catch")
        temp_image_pixels = image_pixels
        temp_image_buffer = image_buffer
        update_transform(x, y)

    render()

    canvas.set_image(image_pixels)

    window.show()
